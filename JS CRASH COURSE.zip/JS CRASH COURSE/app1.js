let data = "Hello";  //empty string
let data2 = "Everyone";

//CONCATENATION
let data3 = data + " " + data2; //strings concatenation
console.log(data3);

//Solving 1
let data5 = 5;
let data4 = Hello;
let data9 = data5 + " " + data4; //addition
console.log(data9);

//Solving 2
let data55 = 5;
let data44 = 5;
let data97 = data55 + " " + data44; //addition
console.log(data97);

//Solving 3
let data52 = 5;
let data12 = 5;
let data19 = data52 + " " + data12;
console.log(data19);
