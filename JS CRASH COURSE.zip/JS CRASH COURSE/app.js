// 1st Class
// let firstName = "Asif";  
// Variable woh jisme data store krwaty hain uski memory me
// Variable // var //let let ziyada use hota hai 
alert(firstName);


// Variable Rules
   // 1. Legal or illegal Names
   // Use Camel Case for Long Variable
   // Legal 
let lastName //CamelCase
//Aik snake case bhi hota hai lekin woh recommended nhi hai 
//let last_name ye snake case hota hai

//Allowed Special Characters
// _ $ 
let $nameWithDollar = "";
let _nameWith_Dollar = "";
// Var cannot be start with a Number
// upper waly dono use krskty hain but recommended nhi hai

// Number use krskty hain but number start me nhi likh skty
let my1Name = ""; 
// OR
let myName1 = ""; 


// Illegal
// let last name // spaces ye dono illegal hain
// Reserved Words (for example let or alert)

// Special Character are not allowed to use in the start middle or end of the variable.
// let my#name is not allowed

// DATA TYPES
// 1. String
// 2. Number
// 3. Boolean

// 1. STRING
let firstName = "Asif"; //koi bhi cheez inverted commas me hogi agar tu woh string hoti hai or "" / '' ye dono same kaam krty hain or string hi show krty hain
// Any letter, word or sentence is Sting in JavaScript
// special Characters bhi string me askty hain
// Example Below;
// sting examples = "Zahid , An Apple" , "8" "a" "email@test.com"

// 2. Number
let myLuckyNumber = 8;
// Number example = 4, 37, 0, 0, -34, 4.765  //Negative, Decimal, zero, postive number sb number data type ayega

// 3. Boolean // true or false hota isme bs
let isTodayMonday = true; // ye inverted comma me nhi rkh skty
// Boolean example = true & false